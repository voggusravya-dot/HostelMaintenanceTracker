"""Central application configuration; environment variables may override defaults."""
from __future__ import annotations
import os
from pathlib import Path

APP_NAME = "Hostel Maintenance Tracker"
APP_DIR = Path(__file__).resolve().parent
DATA_FILE = Path(os.getenv("HOSTEL_TRACKER_DATA", str(APP_DIR / "hostel_requests.json"))).expanduser()
LOG_FILE = Path(os.getenv("HOSTEL_TRACKER_LOG", str(APP_DIR / "hostel_tracker.log"))).expanduser()
WINDOW_SIZE = os.getenv("HOSTEL_TRACKER_WINDOW_SIZE", "1180x760")
MIN_WINDOW_SIZE = (980, 650)
PAGE_SIZE = 100
LOCK_TIMEOUT_SECONDS = 15
