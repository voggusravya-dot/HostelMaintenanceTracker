"""Hostel Maintenance Tracker desktop application."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import csv, logging
from data_store import DataStore, DataValidationError
from config import APP_NAME, DATA_FILE, LOG_FILE, WINDOW_SIZE, MIN_WINDOW_SIZE, PAGE_SIZE

logging.basicConfig(filename=LOG_FILE, level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
LOGGER = logging.getLogger("hostel_tracker")

class HostelTracker:
    PAGE_SIZE = PAGE_SIZE
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME)
        root.geometry(WINDOW_SIZE); root.minsize(*MIN_WINDOW_SIZE); root.configure(bg="#f3f6fb")
        self.store = DataStore(DATA_FILE)
        try: self.data = self.store.load()
        except DataValidationError as exc:
            messagebox.showerror("Data recovery required", str(exc))
            self.data = []
        self.colors = {"nav":"#14213d","bg":"#f3f6fb","white":"#fff","text":"#172033","muted":"#64748b"}
        self.page = 0
        self.setup_style(); self.build_shell(); self.show_dashboard()

    def save_data(self):
        try:
            self.store.save(self.data)
            return True
        except (OSError, DataValidationError) as exc:
            LOGGER.exception("Unable to save data")
            messagebox.showerror("Save Error", f"Could not save records:\n{exc}")
            return False

    def setup_style(self):
        style=ttk.Style()
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("Treeview",font=("Segoe UI",10),rowheight=32,background="white",fieldbackground="white")
        style.configure("Treeview.Heading",font=("Segoe UI",10,"bold"),background="#e8eef7",foreground="#172033")
        style.map("Treeview",background=[("selected","#dbeafe")],foreground=[("selected","#172033")])
        style.configure("TCombobox",padding=6)

    def build_shell(self):
        self.sidebar=tk.Frame(self.root,bg=self.colors["nav"],width=220); self.sidebar.pack(side="left",fill="y"); self.sidebar.pack_propagate(False)
        tk.Label(self.sidebar,text="🛠  HostelCare",bg=self.colors["nav"],fg="white",font=("Segoe UI",18,"bold")).pack(pady=(28,8))
        tk.Label(self.sidebar,text="MAINTENANCE TRACKER",bg=self.colors["nav"],fg="#9fb3d1",font=("Segoe UI",9,"bold")).pack(pady=(0,28))
        for label,action in [("▦  Dashboard",self.show_dashboard),("＋  New Request",self.show_add),("☷  All Requests",self.show_requests),("↗  Export CSV",self.export_csv)]:
            tk.Button(self.sidebar,text=label,command=action,bg=self.colors["nav"],fg="#e6edf8",activebackground="#243657",activeforeground="white",relief="flat",font=("Segoe UI",11),anchor="w",padx=22,pady=13,cursor="hand2").pack(fill="x",padx=8,pady=3)
        tk.Label(self.sidebar,text="LOCAL • OFFLINE • BACKED UP",bg=self.colors["nav"],fg="#8094b5",font=("Segoe UI",8)).pack(side="bottom",pady=20)
        self.main=tk.Frame(self.root,bg=self.colors["bg"]); self.main.pack(side="left",fill="both",expand=True)
        self.header=tk.Frame(self.main,bg=self.colors["bg"]); self.header.pack(fill="x",padx=28,pady=(22,10))
        self.page_title=tk.Label(self.header,text="",bg=self.colors["bg"],fg=self.colors["text"],font=("Segoe UI",22,"bold")); self.page_title.pack(side="left")
        tk.Label(self.header,text="Hostel administration • Requests",bg=self.colors["bg"],fg=self.colors["muted"],font=("Segoe UI",10)).pack(side="right",pady=8)
        self.content=tk.Frame(self.main,bg=self.colors["bg"]); self.content.pack(fill="both",expand=True,padx=28,pady=12)

    def clear_content(self,title):
        for widget in self.content.winfo_children(): widget.destroy()
        self.page_title.config(text=title)

    def card(self,parent,title,value,subtitle,accent):
        box=tk.Frame(parent,bg="white",highlightbackground="#e2e8f0",highlightthickness=1)
        tk.Frame(box,bg=accent,width=5).pack(side="left",fill="y")
        inner=tk.Frame(box,bg="white",padx=18,pady=16); inner.pack(fill="both",expand=True)
        tk.Label(inner,text=title,bg="white",fg="#64748b",font=("Segoe UI",10,"bold")).pack(anchor="w")
        tk.Label(inner,text=str(value),bg="white",fg="#172033",font=("Segoe UI",26,"bold")).pack(anchor="w",pady=4)
        tk.Label(inner,text=subtitle,bg="white",fg="#94a3b8",font=("Segoe UI",9)).pack(anchor="w")
        return box

    def show_dashboard(self):
        self.clear_content("Dashboard")
        statuses=["Pending","In Progress","Completed"]
        counts={s:sum(r["status"]==s for r in self.data) for s in statuses}
        row=tk.Frame(self.content,bg=self.colors["bg"]); row.pack(fill="x")
        for title,val,sub,col in [("Total Requests",len(self.data),"All registered issues","#3b82f6"),("Pending",counts["Pending"],"Awaiting action","#f59e0b"),("In Progress",counts["In Progress"],"Being handled","#8b5cf6"),("Completed",counts["Completed"],"Resolved requests","#10b981")]:
            self.card(row,title,val,sub,col).pack(side="left",fill="x",expand=True,padx=(0,12))
        panel=tk.Frame(self.content,bg="white",highlightbackground="#e2e8f0",highlightthickness=1); panel.pack(fill="both",expand=True,pady=18)
        tk.Label(panel,text="Request Status Analytics",bg="white",fg="#172033",font=("Segoe UI",14,"bold")).pack(anchor="w",padx=18,pady=(14,4))
        try:
            from matplotlib.figure import Figure
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
            fig=Figure(figsize=(7.2,3.2),dpi=100); ax=fig.add_subplot(111)
            labels=statuses; values=[counts[s] for s in labels]
            ax.bar(labels,values,color=["#f59e0b","#8b5cf6","#10b981"])
            ax.set_ylabel("Number of requests"); ax.set_title("Maintenance requests by status")
            ax.grid(axis="y",alpha=.2); fig.tight_layout()
            canvas=FigureCanvasTkAgg(fig,master=panel); canvas.draw(); canvas.get_tk_widget().pack(fill="both",expand=True,padx=12,pady=8)
        except ImportError:
            tk.Label(panel,text="Install Matplotlib to display the visual analytics chart.",bg="white",fg="#64748b").pack(pady=25)
        recent=tk.Frame(self.content,bg="white",highlightbackground="#e2e8f0",highlightthickness=1); recent.pack(fill="both",expand=True)
        tk.Label(recent,text="Recent Maintenance Requests",bg="white",fg="#172033",font=("Segoe UI",13,"bold")).pack(anchor="w",padx=16,pady=10)
        self.make_table(recent,self.data[-5:][::-1],height=5)
        tk.Label(self.content,text="Records are saved locally with an automatic backup before each update.",bg=self.colors["bg"],fg="#64748b",font=("Segoe UI",9)).pack(anchor="w",pady=7)

    def make_table(self,parent,rows,height=12):
        cols=("id","student","room","category","priority","status","date")
        tree=ttk.Treeview(parent,columns=cols,show="headings",height=height)
        headings={"id":"ID","student":"Student Name","room":"Room","category":"Category","priority":"Priority","status":"Status","date":"Date"}
        widths={"id":145,"student":160,"room":85,"category":125,"priority":85,"status":110,"date":130}
        for c in cols: tree.heading(c,text=headings[c]); tree.column(c,width=widths[c],anchor="w")
        for r in rows: tree.insert("","end",values=tuple(r.get(c,"") for c in cols))
        tree.pack(fill="both",expand=True,padx=12,pady=(0,12))
        return tree

    def show_add(self):
        self.clear_content("Register a Request")
        panel=tk.Frame(self.content,bg="white",highlightbackground="#e2e8f0",highlightthickness=1,padx=24,pady=22); panel.pack(fill="both",expand=True)
        tk.Label(panel,text="Enter maintenance issue details",bg="white",fg="#64748b",font=("Segoe UI",10)).grid(row=0,column=0,columnspan=2,sticky="w",pady=(0,18))
        fields={}
        def field(label,r,choices=None):
            tk.Label(panel,text=label,bg="white",fg="#334155",font=("Segoe UI",10,"bold")).grid(row=r,column=0,sticky="w",pady=8)
            var=tk.StringVar()
            widget=ttk.Combobox(panel,textvariable=var,values=choices,state="readonly",width=38) if choices else tk.Entry(panel,textvariable=var,width=42,font=("Segoe UI",10),relief="solid",bd=1)
            if choices: var.set(choices[0])
            widget.grid(row=r,column=1,sticky="w",pady=8,ipady=5); fields[label]=var
        field("Student Name",1); field("Room / Block",2); field("Category",3,["Electrical","Plumbing","Furniture","Cleaning","Internet","Other"])
        field("Priority",4,["Low","Medium","High"]); field("Description",5); panel.grid_columnconfigure(1,weight=1)
        def submit():
            try:
                record=self.store.create_record(fields["Student Name"].get(),fields["Room / Block"].get(),fields["Category"].get(),fields["Priority"].get(),fields["Description"].get(),self.data)
                self.data.append(record)
                if self.save_data(): messagebox.showinfo("Saved","Maintenance request registered successfully."); self.show_requests()
                else: self.data.pop()
            except DataValidationError as exc: messagebox.showwarning("Invalid Details",str(exc))
        tk.Button(panel,text="✓  Submit Request",command=submit,bg="#2563eb",fg="white",relief="flat",font=("Segoe UI",11,"bold"),padx=18,pady=11,cursor="hand2").grid(row=6,column=1,sticky="w",pady=18)

    def show_requests(self):
        self.clear_content("All Requests")
        top=tk.Frame(self.content,bg=self.colors["bg"]); top.pack(fill="x",pady=(0,12))
        search=tk.StringVar(); status=tk.StringVar(value="All"); page_label=tk.StringVar()
        tk.Label(top,text="Search",bg=self.colors["bg"],fg="#64748b").pack(side="left")
        tk.Entry(top,textvariable=search,width=28,font=("Segoe UI",10),relief="solid",bd=1).pack(side="left",padx=8,ipady=6)
        ttk.Combobox(top,textvariable=status,values=["All","Pending","In Progress","Completed"],state="readonly",width=15).pack(side="left",padx=8)
        holder=tk.Frame(self.content,bg="white",highlightbackground="#e2e8f0",highlightthickness=1); holder.pack(fill="both",expand=True)
        nav=tk.Frame(self.content,bg=self.colors["bg"]); nav.pack(fill="x",pady=8)
        state={"page":0,"rows":[]}
        def refresh(*_):
            q=search.get().lower().strip(); st=status.get()
            rows=[r for r in self.data if (st=="All" or r["status"]==st) and q in " ".join(str(r.get(k,"")) for k in self.store.REQUIRED).lower()]
            rows=rows[::-1]; state["rows"]=rows
            pages=max(1,(len(rows)+self.PAGE_SIZE-1)//self.PAGE_SIZE); state["page"]=min(state["page"],pages-1)
            for w in holder.winfo_children(): w.destroy()
            start=state["page"]*self.PAGE_SIZE
            tree=self.make_table(holder,rows[start:start+self.PAGE_SIZE],height=14)
            tree.bind("<Double-1>",lambda e:self.update_selected(tree))
            page_label.set(f"Page {state['page']+1} of {pages} • {len(rows)} records")
            prev.config(state="normal" if state["page"]>0 else "disabled")
            nxt.config(state="normal" if state["page"]<pages-1 else "disabled")
        def move(delta): state["page"]+=delta; refresh()
        prev=tk.Button(nav,text="← Previous",command=lambda:move(-1)); prev.pack(side="left")
        tk.Label(nav,textvariable=page_label,bg=self.colors["bg"],fg="#64748b").pack(side="left",padx=15)
        nxt=tk.Button(nav,text="Next →",command=lambda:move(1)); nxt.pack(side="left")
        search.trace_add("write",lambda *_: (state.update(page=0),refresh()))
        status.trace_add("write",lambda *_: (state.update(page=0),refresh()))
        refresh()
        tk.Label(self.content,text="Double-click a row to update its status. Records are paginated for easier browsing.",bg=self.colors["bg"],fg="#64748b",font=("Segoe UI",9)).pack(anchor="w",pady=5)

    def update_selected(self,tree):
        selection=tree.selection()
        if not selection:return
        rid=tree.item(selection[0],"values")[0]
        record=next((r for r in self.data if r["id"]==rid),None)
        if not record:return
        win=tk.Toplevel(self.root); win.title("Update Request"); win.geometry("380x240"); win.configure(bg="white"); win.resizable(False,False)
        tk.Label(win,text=f'{record["id"]} • {record["student"]}',bg="white",font=("Segoe UI",12,"bold")).pack(pady=18)
        tk.Label(win,text="Change request status:",bg="white").pack()
        value=tk.StringVar(value=record["status"]); ttk.Combobox(win,textvariable=value,values=["Pending","In Progress","Completed"],state="readonly").pack(pady=10)
        def save():
            old=record["status"]; record["status"]=value.get()
            if self.save_data(): win.destroy(); self.show_requests()
            else: record["status"]=old
        tk.Button(win,text="Save Status",command=save,bg="#2563eb",fg="white",relief="flat",padx=18,pady=8).pack(pady=12)

    def export_csv(self):
        if not self.data: messagebox.showinfo("No Data","There are no requests to export yet."); return
        path=filedialog.asksaveasfilename(defaultextension=".csv",filetypes=[("CSV files","*.csv")],initialfile="hostel_maintenance_report.csv")
        if not path:return
        try:
            keys=["id","student","room","category","priority","status","date","description"]
            with open(path,"w",newline="",encoding="utf-8") as handle:
                writer=csv.DictWriter(handle,fieldnames=keys); writer.writeheader(); writer.writerows(self.data)
            messagebox.showinfo("Export Complete",f"Report exported to:\n{path}")
        except OSError as exc:
            LOGGER.exception("CSV export failed"); messagebox.showerror("Export Error",str(exc))

if __name__=="__main__":
    root=tk.Tk(); app=HostelTracker(root); root.mainloop()
