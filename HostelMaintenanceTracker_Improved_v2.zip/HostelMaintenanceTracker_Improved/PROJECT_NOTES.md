# Engineering Notes — Revision 2

## Architecture
- `main.py`: Tkinter presentation layer, dashboard, request workflows, pagination and CSV export.
- `data_store.py`: reusable schema-driven persistence, validation, cross-process locking, atomic writes and backup recovery.
- `config.py`: centralized paths and runtime settings, with environment-variable overrides.
- `tests/test_data_store.py`: persistence, custom-schema, validation, backup and lock-timeout tests.
- `tests/test_ui_integration.py`: end-to-end request submission through the Tkinter form (requires a graphical desktop).

## Data model
Hostel records contain `id`, `student`, `room`, `category`, `priority`, `status`, `date`, and `description`. Allowed categories are Electrical, Plumbing, Furniture, Cleaning, Internet and Other. Allowed priorities are Low, Medium and High. Allowed statuses are Pending, In Progress and Completed.

The persistence layer accepts a `RecordSchema`, so its required fields and enumerated values are configurable rather than embedded in storage operations.

## Reliability and security
- Required fields and enumerated values are validated before persistence.
- Duplicate record IDs are rejected.
- OS-level file locks coordinate concurrent application processes (`msvcrt` on Windows and `fcntl` on POSIX systems).
- JSON writes use a temporary file, flush + fsync, and atomic replacement.
- A backup is created before overwriting an existing data file.
- Errors are logged; malformed records are not silently discarded.
- User input is stored as text and is never evaluated as executable code.
- Data and log paths, window dimensions and pagination size are centralized in configuration.

## Verification
Run `python -m unittest discover -s tests -v`. The GUI integration test automatically skips when no graphical display is available and should be run on a desktop system.
