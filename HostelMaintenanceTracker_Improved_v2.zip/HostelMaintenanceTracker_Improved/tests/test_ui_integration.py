"""End-to-end Tkinter form test; automatically skips on headless systems."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
from tkinter import ttk
import main

class HostelTrackerUITests(unittest.TestCase):
    def setUp(self):
        try:
            self.root = tk.Tk()
        except tk.TclError as exc:
            self.skipTest(f"A graphical display is required for Tkinter integration tests: {exc}")
        self.temp = tempfile.TemporaryDirectory()
        self.old_data_file = main.DATA_FILE
        main.DATA_FILE = Path(self.temp.name) / "requests.json"
        self.app = main.HostelTracker(self.root)

    def tearDown(self):
        if hasattr(self, "root"):
            try: self.root.destroy()
            except tk.TclError: pass
        if hasattr(self, "temp"):
            self.temp.cleanup()
        if hasattr(self, "old_data_file"):
            main.DATA_FILE = self.old_data_file

    def test_user_can_submit_request_through_gui(self):
        self.app.show_add()
        panel = self.app.content.winfo_children()[0]
        entries = [w for w in panel.winfo_children() if isinstance(w, tk.Entry)]
        self.assertEqual(len(entries), 3)
        entries[0].insert(0, "Test Student")
        entries[1].insert(0, "A-101")
        entries[2].insert(0, "Ceiling fan not working")
        submit = next(w for w in panel.winfo_children() if isinstance(w, tk.Button) and "Submit Request" in w.cget("text"))
        with patch.object(main.messagebox, "showinfo"):
            submit.invoke()
        self.assertEqual(len(self.app.data), 1)
        self.assertEqual(self.app.data[0]["student"], "Test Student")
        self.assertEqual(self.app.store.load()[0]["room"], "A-101")

if __name__ == "__main__":
    unittest.main()
