# Hostel Maintenance Tracker

A Python/Tkinter desktop application for registering, tracking and reporting hostel maintenance complaints.

## Features
- Dashboard cards and Matplotlib request-status analytics
- Register requests with required-field and category/priority validation
- Search and filter requests, with pagination for larger datasets
- Update request status and export all records to CSV
- Validated JSON storage, atomic writes, automatic last-known-good backup and recovery
- Cross-process file locking to coordinate multiple application instances
- Centralized configuration with environment-variable overrides
- Automated persistence, validation, locking and GUI integration tests

## Requirements
- Python 3.10+
- Tkinter (included with most standard Python installations)
- Matplotlib (for the dashboard chart)

Install and run:
```bash
python -m pip install -r requirements.txt
python main.py
```

If Matplotlib is unavailable, the application still runs and displays an installation note in the analytics area.

## Run tests
```bash
python -m unittest discover -s tests -v
```
The Tkinter integration test needs a graphical desktop session. On a headless test server it is automatically skipped; run the command on Windows/macOS/Linux desktop to execute it.

## Configuration
Defaults are defined in `config.py`. Optional environment variables:
- `HOSTEL_TRACKER_DATA`: path to the JSON data file
- `HOSTEL_TRACKER_LOG`: path to the application log
- `HOSTEL_TRACKER_WINDOW_SIZE`: initial window size (for example `1280x800`)

## Data integrity
The data file is stored beside the application by default. Before replacing an existing data file, the application creates a `.bak` backup. A separate `.lock` file coordinates access between processes. Temporary files are atomically replaced after data is flushed to disk. Logs are written to `hostel_tracker.log` by default.
