"""Reusable, validated JSON persistence with atomic writes and cross-process locking."""
from __future__ import annotations
import json, os, tempfile, shutil, logging, time
from pathlib import Path
from datetime import datetime
from contextlib import contextmanager
from dataclasses import dataclass, field

LOGGER = logging.getLogger("hostel_tracker")

class DataValidationError(ValueError):
    """Raised when persisted or incoming records violate the configured schema."""

class DataLockTimeout(TimeoutError):
    """Raised when another application process holds the data-file lock too long."""

@dataclass(frozen=True)
class RecordSchema:
    """Schema policy that allows DataStore to be reused with other record types."""
    required_fields: frozenset[str]
    enum_fields: dict[str, frozenset[str]] = field(default_factory=dict)
    non_empty_string_fields: frozenset[str] | None = None

    def validate(self, record):
        if not isinstance(record, dict):
            raise DataValidationError("Each record must be a JSON object.")
        missing = self.required_fields - record.keys()
        if missing:
            raise DataValidationError("Missing fields: " + ", ".join(sorted(missing)))
        string_fields = self.non_empty_string_fields or self.required_fields
        for key in string_fields:
            if key in record and (not isinstance(record[key], str) or not record[key].strip()):
                raise DataValidationError(f"{key} must be a non-empty string.")
        for key, allowed in self.enum_fields.items():
            if record.get(key) not in allowed:
                raise DataValidationError(f"Invalid {key}: {record.get(key)!r}.")
        return record

HOSTEL_SCHEMA = RecordSchema(
    required_fields=frozenset({"id", "student", "room", "category", "priority", "status", "date", "description"}),
    enum_fields={
        "status": frozenset({"Pending", "In Progress", "Completed"}),
        "priority": frozenset({"Low", "Medium", "High"}),
        "category": frozenset({"Electrical", "Plumbing", "Furniture", "Cleaning", "Internet", "Other"}),
    },
)

@contextmanager
def _exclusive_file_lock(lock_path: Path, timeout: float = 15):
    """Acquire an OS-level exclusive lock shared by separate app processes."""
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    handle = lock_path.open("a+b")
    try:
        if os.name == "nt":
            import msvcrt
            handle.seek(0)
            if handle.read(1) == b"":
                handle.seek(0); handle.write(b"0"); handle.flush()
            deadline = time.monotonic() + timeout
            while True:
                try:
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.monotonic() >= deadline:
                        raise DataLockTimeout(f"Timed out waiting for data lock: {lock_path}")
                    time.sleep(0.05)
            try:
                yield
            finally:
                handle.seek(0); msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            deadline = time.monotonic() + timeout
            while True:
                try:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        raise DataLockTimeout(f"Timed out waiting for data lock: {lock_path}")
                    time.sleep(0.05)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    finally:
        handle.close()

class DataStore:
    REQUIRED = HOSTEL_SCHEMA.required_fields
    STATUSES = HOSTEL_SCHEMA.enum_fields["status"]
    PRIORITIES = HOSTEL_SCHEMA.enum_fields["priority"]
    CATEGORIES = HOSTEL_SCHEMA.enum_fields["category"]

    def __init__(self, path="hostel_requests.json", schema: RecordSchema = HOSTEL_SCHEMA, lock_timeout: float = 15):
        self.path = Path(path).expanduser()
        self.backup_path = self.path.with_suffix(self.path.suffix + ".bak")
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self.schema = schema
        self.lock_timeout = lock_timeout

    @classmethod
    def validate_record(cls, record):
        return HOSTEL_SCHEMA.validate(record)

    def _validate_record(self, record):
        return self.schema.validate(record)

    def _validate_records(self, records):
        if not isinstance(records, list):
            raise DataValidationError("The data file must contain a list.")
        seen = set()
        for item in records:
            self._validate_record(item)
            if "id" in item:
                if item["id"] in seen:
                    raise DataValidationError("Duplicate record ID found.")
                seen.add(item["id"])
        return records

    def load(self):
        with _exclusive_file_lock(self.lock_path, self.lock_timeout):
            if not self.path.exists():
                return []
            try:
                with self.path.open("r", encoding="utf-8") as handle:
                    return self._validate_records(json.load(handle))
            except (json.JSONDecodeError, OSError, DataValidationError) as exc:
                LOGGER.exception("Could not load request data")
                if self.backup_path.exists():
                    try:
                        with self.backup_path.open("r", encoding="utf-8") as handle:
                            backup = self._validate_records(json.load(handle))
                        LOGGER.warning("Recovered records from backup")
                        return backup
                    except (OSError, json.JSONDecodeError, DataValidationError):
                        LOGGER.exception("Backup recovery failed")
                raise DataValidationError(f"Data file is invalid and backup recovery failed: {exc}") from exc

    def save(self, records):
        self._validate_records(records)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with _exclusive_file_lock(self.lock_path, self.lock_timeout):
            fd, temp_name = tempfile.mkstemp(prefix=self.path.name, suffix=".tmp", dir=str(self.path.parent))
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as handle:
                    json.dump(records, handle, indent=2, ensure_ascii=False)
                    handle.flush(); os.fsync(handle.fileno())
                if self.path.exists():
                    shutil.copy2(self.path, self.backup_path)
                os.replace(temp_name, self.path)
            except Exception:
                try: os.unlink(temp_name)
                except OSError: pass
                LOGGER.exception("Atomic save failed")
                raise

    @staticmethod
    def create_record(student, room, category, priority, description, existing):
        values = [student, room, category, priority, description]
        if any(not isinstance(v, str) or not v.strip() for v in values):
            raise DataValidationError("All fields are required.")
        stamp = datetime.now(); sequence = 1
        prefix = "HM-" + stamp.strftime("%y%m%d") + "-"
        used = {r.get("id") for r in existing}
        while f"{prefix}{sequence:03d}" in used:
            sequence += 1
        record = {"id": f"{prefix}{sequence:03d}", "student": student.strip(),
                  "room": room.strip(), "category": category, "priority": priority,
                  "status": "Pending", "date": stamp.strftime("%Y-%m-%d %H:%M"),
                  "description": description.strip()}
        return HOSTEL_SCHEMA.validate(record)
