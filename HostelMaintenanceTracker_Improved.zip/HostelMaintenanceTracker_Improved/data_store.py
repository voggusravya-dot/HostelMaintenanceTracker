"""Validated, atomic JSON persistence for Hostel Maintenance Tracker."""
from __future__ import annotations
import json, os, tempfile, shutil, logging
from pathlib import Path
from datetime import datetime

LOGGER = logging.getLogger("hostel_tracker")

class DataValidationError(ValueError):
    pass

class DataStore:
    REQUIRED = {"id", "student", "room", "category", "priority", "status", "date", "description"}
    STATUSES = {"Pending", "In Progress", "Completed"}
    PRIORITIES = {"Low", "Medium", "High"}
    CATEGORIES = {"Electrical", "Plumbing", "Furniture", "Cleaning", "Internet", "Other"}

    def __init__(self, path="hostel_requests.json"):
        self.path = Path(path)
        self.backup_path = self.path.with_suffix(self.path.suffix + ".bak")

    @classmethod
    def validate_record(cls, record):
        if not isinstance(record, dict):
            raise DataValidationError("Each request must be a JSON object.")
        missing = cls.REQUIRED - record.keys()
        if missing:
            raise DataValidationError("Missing fields: " + ", ".join(sorted(missing)))
        for key in ("id", "student", "room", "category", "priority", "status", "date", "description"):
            if not isinstance(record[key], str) or not record[key].strip():
                raise DataValidationError(f"{key} must be a non-empty string.")
        if record["status"] not in cls.STATUSES:
            raise DataValidationError("Invalid request status.")
        if record["priority"] not in cls.PRIORITIES:
            raise DataValidationError("Invalid priority.")
        if record["category"] not in cls.CATEGORIES:
            raise DataValidationError("Invalid category.")
        return record

    def load(self):
        if not self.path.exists():
            return []
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                records = json.load(handle)
            if not isinstance(records, list):
                raise DataValidationError("The data file must contain a list.")
            seen = set()
            for item in records:
                self.validate_record(item)
                if item["id"] in seen:
                    raise DataValidationError("Duplicate request ID found.")
                seen.add(item["id"])
            return records
        except (json.JSONDecodeError, OSError, DataValidationError) as exc:
            LOGGER.exception("Could not load request data")
            # Recover from the last known-good backup when possible.
            if self.backup_path.exists():
                try:
                    with self.backup_path.open("r", encoding="utf-8") as handle:
                        backup = json.load(handle)
                    if isinstance(backup, list):
                        for item in backup:
                            self.validate_record(item)
                        LOGGER.warning("Recovered records from backup")
                        return backup
                except (OSError, json.JSONDecodeError, DataValidationError):
                    LOGGER.exception("Backup recovery failed")
            raise DataValidationError(f"Data file is invalid and backup recovery failed: {exc}") from exc

    def save(self, records):
        if not isinstance(records, list):
            raise DataValidationError("Records must be a list.")
        ids = set()
        for record in records:
            self.validate_record(record)
            if record["id"] in ids:
                raise DataValidationError("Duplicate request ID found.")
            ids.add(record["id"])
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=self.path.name, suffix=".tmp", dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(records, handle, indent=2, ensure_ascii=False)
                handle.flush()
                os.fsync(handle.fileno())
            if self.path.exists():
                shutil.copy2(self.path, self.backup_path)
            os.replace(temp_name, self.path)
        except Exception:
            try: os.unlink(temp_name)
            except OSError: pass
            LOGGER.exception("Atomic save failed")
            raise

    @staticmethod
    def create_record(student, room, category, priority, description, existing):
        values = [student, room, category, priority, description]
        if any(not isinstance(v, str) or not v.strip() for v in values):
            raise DataValidationError("All fields are required.")
        stamp = datetime.now()
        sequence = 1
        prefix = "HM-" + stamp.strftime("%y%m%d") + "-"
        used = {r.get("id") for r in existing}
        while f"{prefix}{sequence:03d}" in used:
            sequence += 1
        record = {"id": f"{prefix}{sequence:03d}", "student": student.strip(),
                  "room": room.strip(), "category": category, "priority": priority,
                  "status": "Pending", "date": stamp.strftime("%Y-%m-%d %H:%M"),
                  "description": description.strip()}
        return DataStore.validate_record(record)
