import json, tempfile, unittest
from pathlib import Path
from data_store import DataStore, DataValidationError

def sample():
    return {"id":"HM-260101-001","student":"Asha","room":"B-12","category":"Electrical",
            "priority":"High","status":"Pending","date":"2026-01-01 10:00","description":"Fan not working"}

class DataStoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.store = DataStore(Path(self.tmp.name) / "requests.json")
    def tearDown(self):
        self.tmp.cleanup()
    def test_save_and_load_round_trip(self):
        self.store.save([sample()])
        self.assertEqual(self.store.load(), [sample()])
    def test_missing_file_returns_empty_list(self):
        self.assertEqual(self.store.load(), [])
    def test_rejects_invalid_status(self):
        bad = sample(); bad["status"] = "Unknown"
        with self.assertRaises(DataValidationError):
            self.store.save([bad])
    def test_rejects_duplicate_ids(self):
        with self.assertRaises(DataValidationError):
            self.store.save([sample(), sample()])
    def test_creates_unique_ids(self):
        first = DataStore.create_record("A","1","Electrical","Low","Issue",[])
        second = DataStore.create_record("B","2","Plumbing","High","Leak",[first])
        self.assertNotEqual(first["id"], second["id"])
    def test_backup_is_created_before_replacement(self):
        self.store.save([sample()])
        changed = sample(); changed["status"] = "Completed"
        self.store.save([changed])
        self.assertTrue(self.store.backup_path.exists())
        self.assertEqual(self.store.load(), [changed])

if __name__ == "__main__":
    unittest.main()
