# Engineering Notes

## Architecture
- `main.py`: Tkinter presentation layer, dashboard, request workflows, pagination and CSV export.
- `data_store.py`: validated persistence boundary, record creation, atomic writes and backup recovery.
- `tests/test_data_store.py`: automated unit tests for the persistence and validation layer.

## Data model
Each request stores: `id`, `student`, `room`, `category`, `priority`, `status`, `date`, and `description`.
Allowed categories: Electrical, Plumbing, Furniture, Cleaning, Internet, Other.
Allowed priorities: Low, Medium, High.
Allowed statuses: Pending, In Progress, Completed.

## Reliability and security measures
- Required fields and enumerated values are validated before persistence.
- Duplicate request IDs and malformed records are rejected.
- JSON writes use a temporary file and atomic replacement.
- A backup is created before overwriting an existing data file.
- Errors are logged without silently discarding corrupted records.
- User-entered values are stored as text and rendered as table data; no user input is executed.

## Verification
Run `python -m unittest discover -s tests -v` to execute the automated unit tests.
