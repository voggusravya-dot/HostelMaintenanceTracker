# Hostel Maintenance Tracker

A Python/Tkinter desktop application for registering and managing hostel maintenance complaints.

## Features
- Dashboard cards and Matplotlib request-status analytics
- Register requests with required-field and category/priority validation
- Search and filter requests, with pagination for larger data sets
- Update request status and export all records to CSV
- Validated JSON storage, atomic writes, automatic last-known-good backup, and application logging
- Automated unit tests for persistence, validation, backup recovery workflow, and unique IDs

## Requirements
- Python 3.10+
- Tkinter (included with most standard Python installations)
- Matplotlib (for the dashboard chart)

Install and run:
```bash
python -m pip install -r requirements.txt
python main.py
```

If Matplotlib is not installed, the rest of the app still runs and displays an installation note in the analytics area.

## Run tests
From this folder:
```bash
python -m unittest discover -s tests -v
```

## Data and safety
Application data is stored in `hostel_requests.json` beside `main.py`. Before replacing an existing data file, the application writes a `.bak` backup. Log messages are written to `hostel_tracker.log`. Keep these files in the same folder as the application.
